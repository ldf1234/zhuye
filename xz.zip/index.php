﻿<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>北极熊安全团队--这个逼我们装定了</title>
<link rel="stylesheet" type="text/css" href="css/reset.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
</head>
<body>
<div class="header">
<div class="header_wrap">
<a href="/" class="logo.jpg"></a>
<ul class="nav">
<li><a href="/index.php" class="current">安全小组</a></li>
<li><a href="#Members" onClick="js_method()">信息展示</a></li>
<li><a href="/jm" target="_blank">在线加密</a></li>
<li><a href="http://blog.74tx.cc" target="_blank">安全博客</a></li>
<li><a href="http://www.74tx.cc" target="_blank">北极熊工具网</a></li>
<li><a href="http://74tx.cc" target="_blank">峰的主页</a></li>
</ul>
</div>
</div>
 
<a name="Members">
</a><div class="content"><a name="Members">
</a><div class="hd"><a name="Members">
<h2>BBYun security team</h2>
<span>人生如棋，我愿为卒；行动虽慢，但谁曾见我后退一步。</span>
</a>
</div>
<div class="bd">
 
<ul class="member_list">
<li class="member_list_item">
<div class="col-sm-6">
 
<div class="ih-item circle effect1">
<a href="#">
<div class="spinner" id="thuai"></div>
<div class="img"><img class="suyibei" src="http://q1.qlogo.cn/g?b=qq&amp;nk=1372960184&amp;s=100"></div>
<div class="info" id="huai">
<div class="info-back">
<h3>北极熊</h3>
<p>技能：网站安全、专注工具开发</p>
<p>我是谁：团队论坛内容、用户运营，站长</p>
</div>
</div>
</a>
</div>
 
</div>
</li>
<li class="member_list_item">
<div class="col-sm-6">
 
<div class="ih-item circle effect1"><a href="#">
<div class="spinner" id="thuai"></div>
<div class="img"><img src="images/0.jpg" alt="img"></div>
<div class="info" id="huai">
<div class="info-back">
<h3>XXXXXXXX</h3>
<p>技能：XXXXXXXX</p>
<p>我是谁：XXXXXXXX</p>
</div>
</div>
</a>
</div>
 
</div>
</li>
<li class="member_list_item">
<div class="col-sm-6">
 
<div class="ih-item circle effect1"><a href="#">
<div class="spinner" id="thuai"></div>
<div class="img"><img src="images/0.jpg" alt="img"></div>
<div class="info" id="huai">
<div class="info-back">
<h3>XXXXXXXX</h3>
<p>技能：XXXXXXXX</p>
<p>我是谁：XXXXXXXX</p>
</div>
</div>
</a>
</div>
 
</div>
</li>
<li class="member_list_item">
<div class="col-sm-6">
 
<div class="ih-item circle effect1"><a href="#">
<div class="spinner" id="thuai"></div>
<div class="img"><img src="images/0.jpg" alt="img"></div>
<div class="info" id="huai">
<div class="info-back">
<h3>XXXXXXXX</h3>
<p>技能：XXXXXXXX</p>
<p>我是谁：XXXXXXXX</p>
</div>
</div>
</a>
</div>
 
</div>
</li>
</ul>
 
 

</div>
</div>
</div>
 
 
 
 
<script>
    function js_method()
    {
       
        var obj=document.getElementsByTagName("div");

        for(i=0;i<obj.length;i++){
             if(obj[i].id=="thuai")
           
            {
              
                obj[i].style.webkitTransform="rotate(180deg)";
                obj[i].style.moztransform="rotate(180deg)";
                obj[i].style.mstransform="rotate(180deg)";
                obj[i].style.otransform="rotate(180deg)";
                obj[i].style.transform="rotate(180deg)";
               

            }
               if(obj[i].id=="huai"){
                obj[i].style.opacity=1;
            }
        }
       
  
    }
</script>
</body>
<div style="display: none">
<audio autoplay="autoplay" loop="loop" src="http://7xj0qv.com1.z0.glb.clouddn.com/ihonker001.mp3"></audio>
</div>
</html>